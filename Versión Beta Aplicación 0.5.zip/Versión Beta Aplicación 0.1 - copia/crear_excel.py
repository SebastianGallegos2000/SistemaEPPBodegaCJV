from openpyxl import Workbook
from openpyxl import load_workbook


def crear_excel(lista_datos,identificadorExcel):
    #wb=Workbook() # funcion para crear una plantilla excel
    list(lista_datos)
    wb=load_workbook('excel_prueba.xlsx') # funcion para utilizar una plantilla ya creada
    hoja = wb.active # se activa la hoja en la que se va a trabajar
    hoja= wb['Epps']
    hoja.title="Epps" # se cambia el titulo de la hoja de la plantilla
    # se crea el encabezado del excel
    #hoja.append(('Bodega','Código','Descripción','Precio por epp','Cantidad de epp','Precio total'))
    # se incertan los valores de las columnas del encabezado
    valor = list(lista_datos)
    for valor in lista_datos:
        hoja.append(valor)
    wb.save('C:\Reportes\R.Excel\Reporte_excel_No.%s.xlsx'%identificadorExcel)
    identificadorExcel+=1

