import pandas as pd
from tkinter import ttk
from tkinter import *
root = Tk()
root.geometry('1280x720')
listbox_prueba = Listbox(root,width=200,height=10)
listbox_prueba.grid(row=1,columnspan=1,sticky=W+E)

boton_guardar = Button(root,text='Guardar datos')
boton_guardar.grid(row=2,column=0)


def funcion_ingreso_trabajadores(id,nombre1,nombre2,nombre3,apellidoP,apellidoM,cargo,fechaIng,gerencia,departamento,seccion,cur,conn):
        id = np_array[0]
        nombre1 = np_array[1]
        nombre2 = np_array[2]
        nombre3 = np_array[3]
        apellidoP = np_array[4]
        apellidoM = np_array[5]
        cargo = np_array[6]
        fechaIng = np_array[7]
        gerencia = np_array[8]
        departamento = np_array[9]
        seccion = np_array[10]


        nombre1 = nombre1.upper()
        nombre2 = nombre2.upper()
        nombre3 = nombre3.upper()
        apellidoM = apellidoM.upper()
        apellidoP = apellidoP.upper()
        cargo = cargo.upper()
        gerencia = gerencia.upper()
        departamento = departamento.upper()
        seccion = seccion.upper()       

        nombre1 = sin_tilde(nombre1)
        nombre2 = sin_tilde(nombre2)
        nombre3 = sin_tilde(nombre3)
        apellidoP = sin_tilde(apellidoP)
        apellidoM = sin_tilde(apellidoM)
        cargo = sin_tilde(cargo)
        gerencia = sin_tilde(gerencia)
        departamento = sin_tilde(departamento)
        seccion = sin_tilde(seccion) 

        nombres = [nombre1,nombre2,nombre3]
        for nombre in nombres:
             if nombre == '':
                  nombre=None
        try:

            sql_insertar = '''
                            INSERT INTO empleado(id, nombre_1, nombre_2, nombre_3, apellido_p, apellido_m, cargo, fecha_de_ingreso, gerencia,departamento, seccion)
                            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s,%s)
                        '''
            cur.execute(sql_insertar,[id,nombre1,nombre2,nombre3,apellidoP,apellidoM,cargo,fechaIng,gerencia,departamento,seccion])
            conn.commit()
            return 1
        except:
             conn.rollback()
             return -1

df = pd.read_excel('trabajadores_ingreso.xlsx')
df.iloc[0].values.tolist()
np_array = df.values
for valor in np_array:
    listbox_prueba.insert(END,valor)



def leer_archivo_excel():
    df=pd.read_excel('',index_col="RUT")
    df.iloc[0].values.tolist()
    np_array = df.values

root.mainloop()