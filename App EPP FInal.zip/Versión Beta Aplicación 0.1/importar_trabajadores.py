import pandas as pd
from tkinter import ttk
from tkinter import *
root = Tk()
root.geometry('1280x720')
listbox_prueba = Listbox(root,width=200,height=10)
listbox_prueba.grid(row=1,columnspan=1,sticky=W+E)

boton_guardar = Button(root,text='Guardar datos')
boton_guardar.grid(row=2,column=0)


def funcion_ingreso_trabajadores(id,nombre1,nombre2,nombre3,apellidoP,apellidoM,cargo,fechaIng,gerencia,departamento,seccion,cur,conn):
        
        i = 1
        vacio = False
        while(i<1000 and not vacio):
            i+=1
            id = np_array[0].value
            nombre1 = np_array[1].value
            nombre2 = np_array[2].value
            nombre3 = np_array[3].value
            apellidoP = np_array[4].value
            apellidoM = np_array[5].value
            cargo = np_array[6].value
            fechaIng = np_array[7].value
            gerencia = np_array[8].value
            departamento = np_array[9].value
            seccion = np_array[10].value

            fila_vacia = (id == None) and (nombre1 == None) and (nombre2 == None) and (nombre3 == None) and (apellidoP==None) and (apellidoM==None) and (cargo == None) and (fechaIng == None) and (gerencia == None) and (departamento == None) and (seccion == None)
            if(fila_vacia):
                 vacio=True
            else:
                 
                parametros =[None,None,None,None,None,None,None,None,None,None,None]
                id = id.strip()
                id = id.split('-')
                id = id[0]
                id = int(id)

        np_array[1] = np_array[1].upper()
        np_array[2] = np_array[2].upper()
        np_array[3] = np_array[3].upper()
        np_array[4] = np_array[4].upper()
        np_array[5] = np_array[5].upper()
        np_array[6] = np_array[6].upper()
        np_array[8] = np_array[8].upper()
        np_array[9] = np_array[9].upper()
        np_array[10] = np_array[10].upper()       

        np_array[1] = sin_tilde(np_array[1])
        np_array[2] = sin_tilde(np_array[2])
        np_array[3] = sin_tilde(np_array[3])
        np_array[4] = sin_tilde(np_array[4])
        np_array[5] = sin_tilde(np_array[5])
        np_array[6] = sin_tilde(np_array[6])
        np_array[8] = sin_tilde(np_array[8])
        np_array[9] = sin_tilde(np_array[9])
        np_array[10] = sin_tilde(np_array[10]) 

        nombres = [nombre1,nombre2,nombre3]
        for nombre in nombres:
             if nombre == '':
                  nombre=None
        try:

            sql_insertar = '''
                            INSERT INTO empleado(id, nombre_1, nombre_2, nombre_3, apellido_p, apellido_m, cargo, fecha_de_ingreso, gerencia,departamento, seccion)
                            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s,%s)
                        '''
            cur.execute(sql_insertar,[np_array[0],np_array[1],np_array[2],np_array[3],np_array[4],np_array[5],np_array[6],np_array[7],np_array[8],np_array[9],np_array[10]])
            conn.commit()
            return 1
        except:
             conn.rollback()
             return -1

df = pd.read_excel('trabajadores_ingreso.xlsx')
df.iloc[0].values.tolist()
np_array = df.values
for valor in np_array:
    listbox_prueba.insert(END,valor)



def leer_archivo_excel():
    df=pd.read_excel('',index_col="RUT")
    df.iloc[0].values.tolist()
    np_array = df.values

root.mainloop()