from openpyxl import Workbook
from openpyxl import load_workbook


def crear_excel(lista_datos,identificadorExcel):
    list(lista_datos)
    wb=load_workbook('excel_base.xlsx') # funcion para utilizar una plantilla ya creada
    hoja = wb.active # se activa la hoja en la que se va a trabajar
    hoja= wb['Epps']
    hoja.title="Epps" # se cambia el titulo de la hoja de la plantilla
    valor = list(lista_datos)

    for valor in lista_datos:
        hoja.append(valor)
    wb.save('C:\Reportes\R.Excel\Reporte_excel_No.%s.xlsx'%identificadorExcel)
    identificadorExcel+=1

